**:warning: The Docs have been moved to [https://docs.ts.injective.network/wallet](https://docs.ts.injective.network/wallet) :warning:**

Injective defines its own custom `Account` type that uses Ethereum's ECDSA secp256k1 curve for keys. In simple words said, it means that Injective's Account is native (compatible) with Ethereum accounts. This allows users to use Ethereum native wallets to interact with Injective.

Injective is built on top of the CosmosSDK. This means that (with some modifications, since Cosmos uses different curve for keys) users can also use Cosmos native wallets to interact with Injective.

---

## Topics

| Topic                                     | Description                                                 |
| ----------------------------------------- | ----------------------------------------------------------- |
| [Accounts on Injective](01WalletAccounts) | Accounts/Wallets definition on Injective                    |
| [Wallet Connections](01WalletConnections) | Connecting directly using Metamask or Keplr                 |
| [Wallet Strategy](01WalletStrategy)       | Using the WalletStrategy to connect using different wallets |
