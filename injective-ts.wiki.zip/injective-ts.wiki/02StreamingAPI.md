**:warning: The Docs have been moved to [https://docs.ts.injective.network/querying/querying-api/streaming](https://docs.ts.injective.network/querying/querying-api/streaming) :warning:**

## Streaming the Indexer

## Topics

| Topic                                               | Description                               |
| --------------------------------------------------- | ----------------------------------------- |
| [Account Module](02StreamingIndexerAccount)         | Streaming data from the account module    |
| [Auction Module](02StreamingIndexerAuction)         | Streaming data from the auction module    |
| [Derivatives Module](02StreamingIndexerDerivatives) | Stream data from the derivatives module   |
| [Explorer Module](02StreamingIndexerExplorer)       | Stream data from the the explorer module  |
| [Oracle Module](02StreamingIndexerOracle)           | Stream data from the the oracle           |
| [Portfolio Module](02StreamingIndexerPortfolio)     | Stream data from the the portfolio module |
| [Spot Module](02StreamingIndexerSpot)               | Stream data from the spot module          |

---
