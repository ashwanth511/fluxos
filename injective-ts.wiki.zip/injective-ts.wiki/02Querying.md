**:warning: The Docs have been moved to [https://docs.ts.injective.network/querying](https://docs.ts.injective.network/querying) :warning:**

There are 2 data sources that can be accessed through the `sdk-ts`:

- The Injective chain itself through a sentry node,
- The Indexer API (indexer of events from the Injective chain to a MongoDB),

For each of the data sources there are two ways that they can be queried:

- using the gRPC protocol,
- Using HTTP REST

We also have a GraphQL consumer of the Peggy subgraph on Ethereum (used only for tracking deposits and withdrawals on Ethereum).

For the 2 main data sources, there are abstraction classes that developers can use to access specific modules of the Injective Chain **or** specific modules within the Exchange API. The responses of these requests are always mapped into normal JavaScript objects (regardless of the data source type) and served to the end user.

---

## Topics

| Topic                                                  | Description                         |
| ------------------------------------------------------ | ----------------------------------- |
| [Querying the Chain](02QueryingChain)                  | Querying data from the chain        |
| [Querying the Indexer API](02QueryingAPI)              | Querying data from the Indexer API  |
| [Steaming from the Indexer API](02StreamingAPI)        | Streaming data from the Indexer API |
| [Querying Ethereum from the Graph](02QueryingEthereum) | Querying Ethereum via GraphQL       |
| [CosmWasm Query Payloads](02QueryingCosmWasm)          | Get payloads for CosmWasm queries   |

---
