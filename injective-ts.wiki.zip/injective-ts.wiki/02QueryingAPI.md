**:warning: The Docs have been moved to [https://docs.ts.injective.network/querying/querying-api](https://docs.ts.injective.network/querying/querying-api) :warning:**

## Querying the Indexer

## Topics

| Topic                                                   | Description                                      |
| ------------------------------------------------------- | ------------------------------------------------ |
| [Account Module](02QueryingIndexerAccount)              | Querying data from the account module            |
| [Auction Module](02QueryingIndexerAuction)              | Querying data from the auction module            |
| [Derivatives Module](02QueryingIndexerDerivatives)      | Query data from the derivatives module           |
| [Explorer Module](02QueryingIndexerExplorer)            | Query data related to the explorer module        |
| [Insurance Fund Module](02QueryingIndexerInsuranceFund) | Query data from the insurance fund module        |
| [Ninja Vaults Module](02QueryingIndexerNinja)           | Query data from the ninja vaults module          |
| [Oracle Module](02QueryingIndexerOracle)                | Query data related to the oracle                 |
| [Portfolio Module](02QueryingIndexerPortfolio)          | Query data related to the portfolio module       |
| [Spot Module](02QueryingIndexerSpot)                    | Query data from the spot module                  |
| [Transaction Module](02QueryingIndexerTransaction)      | Query data related to the transaction module     |
| [Leaderboard Module](02QueryingIndexerLeaderboard)      | Query data related to the leaderboard module     |
| [Markets Module](02QueryingIndexerMarkets)              | Query data for both spot and derivatives markets |

---
