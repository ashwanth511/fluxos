**:warning: The Docs have been moved to [https://docs.ts.injective.network/core-modules](https://docs.ts.injective.network/core-modules) :warning:**

Within this section we are going to explore the core modules of the Injective chain and provide examples on how to make and broadcast transactions for each of the Messages defined on-chain.

---

## Topics

| Topic                                            | Description                                      |
| ------------------------------------------------ | ------------------------------------------------ |
| [Auction Module](04CoreModulesAuction)           | Use for the buy-back-and-burn on chain mechanism |
| [Bank Module](04CoreModulesBank)                 | Used for managing users assets (funds)           |
| [Exchange Module](04CoreModulesExchange)         | Used for the exchange primitives                 |
| [IBC Module](04CoreModulesIBC)                   | Used for cross-Cosmos chain transfers            |
| [Staking Module](04CoreModulesStaking)           | Used for on-chain staking                        |
| [Peggy Module](04CoreModulesPeggy)               | Used for the Injective <> Ethereum Bridge        |
| [Distribution Module](04CoreModulesDistribution) | Used for on-chain distribution/minting           |
| [Gov Module](04CoreModulesGov)                   | Used for on-chain governance                     |
| [Insurance Module](04CoreModulesInsurance)       | Used for on-chain insurance funds                |
| [Wasm Module](04CoreModulesWasm)                 | Used for interacting with the Cosmwasm Layer     |
| [Authz Module](04CoreModulesAuthz)               | Used for granting account priveledges            |
