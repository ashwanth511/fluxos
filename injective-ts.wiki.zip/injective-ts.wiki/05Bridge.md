**:warning: The Docs have been moved to [https://docs.ts.injective.network/bridge](https://docs.ts.injective.network/bridge) :warning:**

Injective is a blockchain built specifically to support financial applications. A key strength of Injective is its ability to perform seamless cross-chain transactions with the majority of popular blockchains.

Right now, the two main bridges supported on Injective are:

1. Peggy (Ethereum) Bridge - connecting Injective and Ethereum,
2. IBC Bridge - connecting Injective and other Cosmos chains,

---

## Topics

| Topic                               | Description                             |
| ----------------------------------- | --------------------------------------- |
| [Ethereum Bridge](05BridgeEthereum) | Bridging to/from Injective <-> Ethereum |
| [IBC Bridge](05BridgeIBC)           | Bridging to/from Injective using IBC    |

---
