**:warning: The Docs have been moved to [https://docs.ts.injective.network/querying/querying-chain](https://docs.ts.injective.network/querying/querying-chain) :warning:**

## Querying the Chain

## Topics

| Topic                                              | Description                                    |
| -------------------------------------------------- | ---------------------------------------------- |
| [Auction Module](02QueryingChainAuction)           | Querying data from the auction module          |
| [Auth Module](02QueryingChainAuth)                 | Querying data from the auth module             |
| [Bank Api](02QueryingChainBank)                    | Query data from the bank module                |
| [Distribution API](02QueryingChainDistribution)    | Query data related to delegating to validators |
| [Exchange Module](02QueryingChainExchange)         | Query data from the exchange module            |
| [Gov Module](02QueryingChainGov)                   | Query data from the governance module          |
| [IBC Api](02QueryingChainIBC)                      | Query data related to IBC                      |
| [Insurance Fund Api](02QueryingChainInsuranceFund) | Query data related to insurance funds          |
| [Mint Module](02QueryingChainMint)                 | Query data from the mint module                |
| [Oracle Api](02QueryingChainOracle)                | Query data related to the oracle api           |
| [Peggy Api](02QueryingChainPeggy)                  | Query ethereum data using the peggy api        |
| [Staking Module](02QueryingChainStaking)           | Query data from the staking module             |
| [Wasm Module](02QueryingChainWasm)                 | Query data from the wasm module                |
| [WasmX Module](02QueryingChainWasmX)               | Query data from the wasmX module               |
| [Tendermint Api](02QueryingChainTendermint)        | Query data related to the tendermint api       |

---

---
